import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoursesCardComponent } from './courses-card/courses-card.component';
import { ReviewCardComponent } from './review-card/review-card.component';

@NgModule({
  declarations: [CoursesCardComponent, ReviewCardComponent],
  imports: [CommonModule],
  exports: [CoursesCardComponent,ReviewCardComponent],
})
export class CommonComponentsModule {}
