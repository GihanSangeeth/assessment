import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  reviews = [
    {
      name: 'Shelley Marshall',
      desc: 'I have loved doing this level 4 Skincare course with Global Ed. The information in this course',
      posted: '1 day',
    },
    {
      name: 'Corey Airey',
      desc: 'Very informative course. I have learnt alot and found the course easy to follow.',
      posted: '4 days',
    },
    {
      name: 'Tash',
      desc: 'I bought an online course Diploma in Office Administration and Reception',
      posted: '4 days',
    },
  ];

  brands = [
    {
      name: 'brand1',
      logo: 'assets/images/brands/actopus.png',
    },
    {
      name: 'brand2',
      logo: 'assets/images/brands/amazon.png',
    },
    {
      name: 'brand3',
      logo: 'assets/images/brands/aston.png',
    },
    {
      name: 'brand4',
      logo: 'assets/images/brands/bottomline.png',
    },
    {
      name: 'brand5',
      logo: 'assets/images/brands/jaguar.png',
    },
    {
      name: 'brand6',
      logo: 'assets/images/brands/land-rover.png',
    },
    {
      name: 'brand7',
      logo: 'assets/images/brands/nhs.png',
    },
    {
      name: 'brand8',
      logo: 'assets/images/brands/salesforce.png',
    },
  ];
  awardList = [
    {
      name: 'award1',
      logo: 'assets/images/awards/bcs.png',
    },
    {
      name: 'award2',
      logo: 'assets/images/awards/cdp.png',
    },
    {
      name: 'award2',
      logo: 'assets/images/awards/athe.png',
    },
    {
      name: 'award2',
      logo: 'assets/images/awards/cmi.png',
    },
    {
      name: 'award2',
      logo: 'assets/images/awards/comptia.png',
    },
    {
      name: 'award2',
      logo: 'assets/images/awards/iap.png',
    },
    {
      name: 'award2',
      logo: 'assets/images/awards/iassc.png',
    },
    {
      name: 'award2',
      logo: 'assets/images/awards/pearson.png',
    },
    {
      name: 'award2',
      logo: 'assets/images/awards/people-set.png',
    },
    {
      name: 'award2',
      logo: 'assets/images/awards/qls.png',
    },
    {
      name: 'award2',
      logo: 'assets/images/awards/sage.png',
    },
    {
      name: 'award2',
      logo: 'assets/images/awards/tquk.png',
    },
  ];

  coursesList = [
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'PRINCE2® Practitioner',
      rating: '70%',
      time: '1 year',
      price: '£600.00',
      award: 'AXELOS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'PRINCE2® Practitioner',
      rating: '70%',
      time: '1 year',
      price: '£600.00',
      award: 'AXELOS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'PRINCE2® Practitioner',
      rating: '70%',
      time: '1 year',
      price: '£600.00',
      award: 'AXELOS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
  ];
  newCoursesList = [
    {
      name: 'PRINCE2® Practitioner',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'First Aid at Work - Level 3',
      rating: '70%',
      time: '1 year',
      price: '£600.00',
      award: 'AXELOS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'First Aid at Work - Level 3',
      rating: '70%',
      time: '1 year',
      price: '£600.00',
      award: 'AXELOS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'First Aid at Work - Level 3',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'PRINCE2® Practitioner',
      rating: '70%',
      time: '1 year',
      price: '£600.00',
      award: 'AXELOS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
  ];
  areas = [
    {
      name: 'Project Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-370.png',
    },
    {
      name: 'Business & Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-368.png',
    },
    {
      name: 'Project Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-370.png',
    },
    {
      name: 'Business & Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-368.png',
    },
    {
      name: 'Project Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-370.png',
    },
    {
      name: 'Business & Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-368.png',
    },
    {
      name: 'Project Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-370.png',
    },
    {
      name: 'Business & Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-368.png',
    },
    {
      name: 'Project Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-370.png',
    },
    {
      name: 'Business & Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-368.png',
    },
    {
      name: 'Project Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-370.png',
    },
    {
      name: 'Business & Management',
      image:
        'https://www.globaledulink.co.uk/wp-content/uploads/2021/10/img-368.png',
    },
  ];
  constructor() {}

  ngOnInit(): void {}
}
