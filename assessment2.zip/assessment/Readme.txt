Need Angular version 13.3.1
node version 16.13.2

Open edulink-assessment folder in cmd/vscode terminal and run below commands.
 1.npm install
 2.ng serve