Need Angular version 13.3.1

Open edulink-assessment folder in cmd/vscode terminal and run below commands.
 1.npm install
 2.ng serve