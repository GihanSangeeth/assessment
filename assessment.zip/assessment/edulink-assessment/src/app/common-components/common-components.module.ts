import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoursesCardComponent } from './courses-card/courses-card.component';

@NgModule({
  declarations: [CoursesCardComponent],
  imports: [CommonModule],
  exports: [CoursesCardComponent],
})
export class CommonComponentsModule {}
