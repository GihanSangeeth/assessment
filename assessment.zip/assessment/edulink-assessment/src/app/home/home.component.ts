import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  coursesList = [
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%,',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'PRINCE2® Practitioner',
      rating: '70%,',
      time: '1 year',
      price: '£600.00',
      award: 'AXELOS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%,',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'PRINCE2® Practitioner',
      rating: '70%,',
      time: '1 year',
      price: '£600.00',
      award: 'AXELOS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%,',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%,',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
  ];
  newCoursesList = [
    {
      name: 'PRINCE2® Practitioner',
      rating: '20%,',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'First Aid at Work - Level 3',
      rating: '70%,',
      time: '1 year',
      price: '£600.00',
      award: 'AXELOS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%,',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'First Aid at Work - Level 3',
      rating: '70%,',
      time: '1 year',
      price: '£600.00',
      award: 'AXELOS',
      imgUrl: 'assets/images/image2.jpg',
    },
    {
      name: 'CIPD Level 3 Foundation Certificate in People Practice',
      rating: '20%,',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
    {
      name: 'First Aid at Work - Level 3',
      rating: '20%,',
      time: '1 year',
      price: '£469.00',
      award: 'BCS',
      imgUrl: 'assets/images/image1.jpg',
    },
  ];
  constructor() {}

  ngOnInit(): void {}
}
